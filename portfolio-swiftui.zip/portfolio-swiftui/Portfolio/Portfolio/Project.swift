//
//  Project.swift
//  Portfolio
//
//  Created by Bryant Anthony Thauwrisan on 17/07/24.
//

import SwiftUI

struct Project: View {
    var body: some View {
        NavigationView {
            ScrollView {
                ZStack {
                    Color("orangeBackground")
                        .ignoresSafeArea()
                    
                    VStack {
                        ForEach(Projects) { project in
                            ProjectCard(project: project)
                                .frame(maxWidth: .infinity)
                                .padding()
                        }
                    }
                    .padding()
                }
            }
            .background(Color("orangeBackground").edgesIgnoringSafeArea(.all))
            .navigationTitle("Project")
        }
    }
}

struct Project_Previews: PreviewProvider {
    static var previews: some View {
        Project()
    }
}

struct ProjectCard: View {
    var project: ProjectData
    @State private var isFlipped = false
    @State private var isExpanded = false
    
    var body: some View {
        ZStack {
            if isFlipped {
                backCard
            } else {
                frontCard
            }
        }
        .foregroundColor(.white)
        .padding(10)
        .background(Color.orange)
        .cornerRadius(20)
        .shadow(radius: 5)
        .onTapGesture {
            withAnimation {
                isFlipped.toggle()
            }
        }
    }
    
    var frontCard: some View {
        VStack {
            Text(project.title)
                .multilineTextAlignment(.center)
                .fontWeight(.bold)
                .font(.title3)
            Text(project.shortDescription)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
        }
        .padding()
    }
    
    var backCard: some View {
        ScrollView {
            VStack {
                Text(project.role)
                    .multilineTextAlignment(.center)
                    .fontWeight(.bold)
                    .font(.title3)
                if isExpanded {
                    Text(project.detailedDescription)
                        .multilineTextAlignment(.center)
                        .padding(.top, 10)
                } else {
                    Text(project.detailedDescription)
                        .lineLimit(3) // Show only a few lines
                        .multilineTextAlignment(.center)
                        .padding(.top, 10)
                }
                Button(action: {
                    withAnimation {
                        isExpanded.toggle()
                    }
                }) {
                    Text(isExpanded ? "Read Less" : "Read More")
                        .foregroundColor(.blue)
                        .padding(.top, 10)
                }
            }
            .padding()
        }
    }
}

struct ProjectCard_Previews: PreviewProvider {
    static var previews: some View {
        ProjectCard(project: Projects[0])
    }
}


// Data Project
struct ProjectData: Identifiable {
    let id = UUID()
    let title: String
    let shortDescription: String
    let role: String
    let detailedDescription: String
}

let Projects = [
    ProjectData(title: "Sistem Toko Emas Perhiasan Dua Tujuh", 
                shortDescription: "The system was developed during the completion of the Final Project (Thesis) using the Laravel framework. I worked on this system as a Fullstack Developer.",
                role: "as Full Stack Developer",
                detailedDescription: "Introducing the 'Dua Tujuh' Jewelry Store System, a Laravel-based web application designed to efficiently manage the sales and purchases of jewelry. This system is specifically created for store owners and employees, with different access rights according to their roles. Employees can record sales transactions, including item details, prices, and customer information, as well as purchase transactions from suppliers, while stock is updated automatically. With a secure login system using Laravel authentication, the owner has full control to manage all aspects of the system, while employees have limited access to manage sales transactions and check item availability."),
    ProjectData(title: "Drakonnect",
                shortDescription: "Drakonnect was developed only up to the prototyping stage, which was done directly in XCode (front-end development directly in the application).",
                role: "as Developer, UI Designer, UX Designer / Researcher",
                detailedDescription: "Introducing Drakonnect, an iOS application that helps you find the perfect K-Drama community. Explore a world of comfort and connection as we match you with communities that align with your preferences. Discover detailed information about each community, tailored to your interests. Enjoy endless conversations, shared excitement, and a sense of belonging. Get ready to connect with fellow K-Drama fans like never before. It's time to make your K-Drama journey even more unforgettable with Drakonnect!"),
    ProjectData(title: "Nutriguide",
                shortDescription: "This application was developed as part of the mini challenge 2 project using Apple's technology, SwiftUI. In the development of this application, I served as the UI/UX Designer in the team.",
                role: "as UI Designer, UX Designer / Researcher",
                detailedDescription: "An iOS App to help you decide on snacking with just 2 easy steps! Scan, Input, Boom! Ever realized what you're consuming is much more than what you think? NutriGuide will prove that you should be cautious on what you consume! \n\n✨FEATURES✨ \n1. Personalized Limitation 👩🏻‍🦰 \n2. Detailed Amount 📝 \n 3. Search Products 🔍 \n4. Save Products ✅ \n5. Manually Add Products ➕")
]
