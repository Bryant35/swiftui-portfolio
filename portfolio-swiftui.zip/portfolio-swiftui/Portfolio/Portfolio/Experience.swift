import SwiftUI

struct Experience: View {
    var experienceEvents: [TimelineEvent]
    var educationEvents: [TimelineEvent]
    
    var body: some View {
        NavigationView {
            ScrollView {
                ZStack {
                    Color("orangeBackground")
                        .ignoresSafeArea()
                    
                    LazyVStack(alignment: .leading, spacing: 0) {
                        sectionTitle("Experience")
                        ForEach(Array(experienceEvents.enumerated()), id: \.element.id) { index, event in
                            ExpCard(exp: event, isLast: index == experienceEvents.count - 1, isFirst: index == 0)
                        }
                        
                        sectionTitle("Education")
                        ForEach(Array(educationEvents.enumerated()), id: \.element.id) { index, event in
                            ExpCard(exp: event, isLast: index == educationEvents.count - 1, isFirst: index == 0)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("Experience")
            .background(Color("orangeBackground").edgesIgnoringSafeArea(.all))
        }
    }
    
    private func sectionTitle(_ title: String) -> some View {
        ZStack {
            Divider().padding(.vertical, 20)
            Text(title)
                .padding(.horizontal, 15)
                .background(Color("orangeBackground"))
        }
    }
}

struct ExpCard: View {
    var exp: TimelineEvent
    var isLast: Bool
    var isFirst: Bool
    
    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            GeometryReader { geometry in
                ZStack() {
                    Circle()
                        .foregroundColor(Color.orange)
                        .frame(width: 16, height: 16)
                        .overlay(
                            Circle()
                                .stroke(Color.white, lineWidth: 2)
                        )
                        .position(x: 8, y: geometry.size.height / 2)
                        .zIndex(/*@START_MENU_TOKEN@*/1.0/*@END_MENU_TOKEN@*/)
                    if isFirst{
                        Rectangle()
                            .foregroundColor(Color.orange)
                            .frame(width: 4)
                            .frame(height: geometry.size.height / 2 + 30)
                            .padding(.top, geometry.size.height / 2)
                    }else if isLast {
                        Rectangle()
                            .foregroundColor(Color.orange)
                            .frame(width: 4)
                            .frame(height: geometry.size.height / 2)
                            .padding(.bottom, geometry.size.height / 2)
                    }else{
                        Rectangle()
                            .foregroundColor(Color.orange)
                            .frame(width: 4, height: geometry.size.height + 30)
                            .frame(maxHeight: .infinity)
                    }
                }
            }
            .frame(width: 16)
            
            VStack(alignment: .leading, spacing: 8) {
                Text(exp.date)
                    .font(.caption)
                    .foregroundColor(.gray)
                
                Text(exp.title)
                    .font(.headline)
                
                Text(exp.description)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
        }
        .padding(.vertical, 10)
    }
}


struct Experience_Previews: PreviewProvider {
    static var previews: some View {
        Experience(experienceEvents: EventExp, educationEvents: EventEdu)
    }
}

struct TimelineEvent: Identifiable {
    let id = UUID()
    let date: String
    let title: String
    let description: String
}


//Data
let EventExp = [
    TimelineEvent(date: "2023", title: "Apple Developer Academy@UC", description: "Intern As Tech"),
    TimelineEvent(date: "2022 - 2023", title: "Student Union Publication and Documentation", description: "Photographer and Videographer"),
    TimelineEvent(date: "2022", title: "Head Koor of PDD UC Oweek 2022", description: "Photographer and Videographer"),
    TimelineEvent(date: "2021", title: "Committee Member of PDD UC Oweek 2021", description: "Photographer and Videographer")
]


let EventEdu = [
    TimelineEvent(date: "2020 - 2024", title: "Ciputra University Surabaya", description: "Information Systems (GPA 3.79/4)"),
    TimelineEvent(date: "2017 - 2020", title: "SMA Zion Makassar", description: "IPS(Social)")
]
