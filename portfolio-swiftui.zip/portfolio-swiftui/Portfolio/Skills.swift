//
//  Skills.swift
//  Portfolio
//
//  Created by Bryant Anthony Thauwrisan on 17/07/24.
//

import SwiftUI

struct Skills: View {
    var SkillList: [SkillData]
    
    var body: some View {
        NavigationView {
            ScrollView {
                ZStack {
                    Color("orangeBackground")
                        .ignoresSafeArea()
                    VStack(spacing: 20) {
                        ForEach(Array(SkillList.enumerated()), id: \.element.id) { index, event in
                            SkillView(data: event)
                        }
                    }
                    .padding([.horizontal, .top])
                }
            }
            .navigationTitle("Skills")
            .background(Color("orangeBackground").edgesIgnoringSafeArea(.all))
        }
    }
}

struct Skills_Previews: PreviewProvider {
    static var previews: some View {
        Skills(SkillList: SkillsData)
    }
}

struct SkillView: View {
    var data: SkillData
    @State private var showRate = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack{
                AsyncImage(url: URL(string: data.img)) { image in
                    image.resizable()
                } placeholder: {
                    Color.red
                }
                .aspectRatio(contentMode: .fit)
                .frame(height: 30)
//                .clipShape(.rect(cornerRadius: 25))
                Text(data.skills)
                    .font(.headline)
                    .foregroundColor(.black)
            }
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Rectangle()
                        .frame(height: 20)
                        .foregroundColor(.gray)
                    
                    Rectangle()
                        .frame(width: geometry.size.width * CGFloat(data.rate) / 100, height: 20)
                        .foregroundColor(.orange)
                        .overlay(
                            Text("\(Int(data.rate))%")
                                .foregroundColor(.white)
                                .font(.caption)
                                .padding(.horizontal, 5),
//                                .background(Color.black.opacity(0.7))
//                                .cornerRadius(5)
//                                .opacity(showRate ? 1 : 0),
                            alignment: .leading
                        )
//                        .onTapGesture {
//                            withAnimation {
//                                showRate.toggle()
//                            }
//                        }
                }
                .cornerRadius(10)
            }
            .frame(height: 20) // Set a fixed height for the GeometryReader
        }
        .padding(.vertical, 5)
    }
}

struct SkillData: Identifiable {
    let id = UUID()
    let img: String
    let skills: String
    let rate: Float
}

let SkillsData = [
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/HTML5_logo_and_wordmark.svg/1024px-HTML5_logo_and_wordmark.svg.png" ,skills: "HTML", rate: 65),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/CSS3_logo_and_wordmark.svg/340px-CSS3_logo_and_wordmark.svg.png" ,skills: "CSS", rate: 50),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/2560px-PHP-logo.svg.png" ,skills: "PHP", rate: 70),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/6/6a/JavaScript-logo.png" ,skills: "JavaScript", rate: 40),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/labs/8/8e/Mysql_logo.png" ,skills: "MySQL", rate: 75),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Laravel.svg/985px-Laravel.svg.png" ,skills: "Laravel", rate: 75),
    SkillData(img:"https://developer.apple.com/assets/elements/icons/swiftui/swiftui-96x96_2x.png" ,skills: "SwiftUI", rate: 35),
    SkillData(img:"https://getbootstrap.com/docs/5.3/assets/brand/bootstrap-logo-shadow.png" ,skills: "Bootstrap", rate: 55),
    SkillData(img:"https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Tailwind_CSS_Logo.svg/1024px-Tailwind_CSS_Logo.svg.png" ,skills: "Tailwind", rate: 45),
]
