//
//  PortfolioApp.swift
//  Portfolio
//
//  Created by Bryant Anthony Thauwrisan on 17/07/24.
//

import SwiftUI

@main
struct PortfolioApp: App {
    var body: some Scene {
        WindowGroup {
            Tab()
        }
    }
}
