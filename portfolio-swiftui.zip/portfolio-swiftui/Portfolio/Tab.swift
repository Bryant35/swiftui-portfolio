import SwiftUI

struct Tab: View {
    
    //Set navigation Color
    init() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.orange]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.orange]
        appearance.backgroundColor = UIColor(named: "orangeBackground")
        
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().compactAppearance = appearance
        //        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View {
        TabView {
            Profile()
                .tabItem {
                    Label("Profile", systemImage: "person.text.rectangle")
                }
            Experience(experienceEvents: EventExp, educationEvents: EventEdu)
                .tabItem {
                    Label("Experience", systemImage: "case")
                }
            Project()
                .tabItem {
                    Label("Project", systemImage: "laptopcomputer")
                }
            Skills(SkillList: SkillsData)
                .tabItem {
                    Label("Skills", systemImage: "star")
                }
        }
        .accentColor(.orange)
    }
}

#Preview {
    Tab()
}
