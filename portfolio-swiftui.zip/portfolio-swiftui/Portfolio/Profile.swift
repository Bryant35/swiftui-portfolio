//
//  Profile.swift
//  Portfolio
//
//  Created by Bryant Anthony Thauwrisan on 17/07/24.
//

import SwiftUI
import PDFKit

struct Profile: View {
    @State private var showPDF = false
    @State private var pdfHeight: CGFloat = 0
    
    //Set how much Columns
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        NavigationView{
            ScrollView{
                ZStack{
                    Color("orangeBackground")
                        .ignoresSafeArea()
                    VStack(){
                        //image
                        Group{
                            Image("profile-img")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .frame(width: 125)
                                .shadow(color: .black, radius: 6)
                                .overlay {
                                    Circle()
                                        .stroke(Color.orange, lineWidth: 2)
                                }
                                .padding(.top, 20)
                        }
                        //Name
                        Group{
                            Text("Bryant Anthony Thauwrisan")
                                .font(.title3)
                                .foregroundColor(Color.orange)
                                .multilineTextAlignment(.leading)
                                .fontWeight(.bold)
                                .padding(.top, 5)
                            Text("Developer")
                                .multilineTextAlignment(.leading)
                                .font(.subheadline)
                        }
                        
                        Button(action: {
                            showPDF.toggle()
                        }) {
                            Text("View PDF")
                                .foregroundColor(.white)
                                .fontWeight(.bold)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(10)
                        }
                        .sheet(isPresented: $showPDF) {
                            if let pdfURL = Bundle.main.url(forResource: "CV-BryantAT", withExtension: "pdf"),
                               let pdfDocument = PDFDocument(url: pdfURL) {
                                PDFViewer(pdfDocument: pdfDocument, showPDF: $showPDF)
                                //                                    .frame(height: pdfHeight)
                                    .onAppear {
                                        if let page = pdfDocument.page(at: 0) {
                                            let pdfPageBounds = page.bounds(for: .mediaBox)
                                            pdfHeight = pdfPageBounds.height
                                        }
                                    }
                            } else {
                                Text("PDF not found")
                            }
                        }
                        
                        Divider()
                            .padding(15)
                        
                        Text("I am an graduand student at Ciputra University Surabaya, majoring in Information Systems. I have experience in website development using the Laravel Framework and MySQL since college. I completed a 10-month internship at Apple Developer Academy@UC, where I learned Swift, particularly SwiftUI, and iOS app design using Human Interface Guidelines (HIG). My education and experience have given me strong skills in web and mobile app development, and I am eager to continue growing in the information technology industry.")
                            .multilineTextAlignment(.center)
                            .lineSpacing(7.5)
                        
                        Divider()
                            .padding(15)
                        
                        SelfData()
                    }
                }
                .padding(.bottom, 15)
            }.navigationTitle("Profile")
                .padding(.horizontal,10)
                .background(Color("orangeBackground"))
            
        }
        
    }
    
    
    func SelfData()->some View{
        LazyVGrid(columns: columns, spacing: 25, content: {
            VStack{
                Text("Phone")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Text("(+62)813-8687-8778")
            }//Phone
            VStack{
                Text("Birth Date")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Text("3rd May 2002")
            }//Birth Date
            VStack{
                Text("Email")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Link(destination: URL(string:
                                        "mailto:bryantthauwrisan7@gmail.com")!, label: {
                    Text("bryantthauwrisan7@gmail.com")
                        .underline()
                        .font(.callout)
                        .accentColor(.black)
                })
                
            }//Email
            VStack{
                Text("Domicile")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Text("Surabaya, East Java")
            }//Domicile
            VStack{
                Text("Website")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Link(destination: URL(string: "http://bryant35.site")!, label: {
                    Text("bryant35.site")
                        .underline()
                        .font(.callout)
                        .accentColor(.black)
                })
            }//Website
            VStack{
                Text("From")
                    .fontWeight(.bold)
                    .font(.headline)
                    .foregroundColor(.orange)
                Text("Makassar, South Sulawesi")
            }//Born Place
        }).multilineTextAlignment(.center)
    }
}

struct PDFKitView: UIViewControllerRepresentable {
    let pdfDocument: PDFDocument
    @Binding var contentHeight: CGFloat
    
    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = UIViewController()
        let pdfView = PDFView()
        pdfView.document = pdfDocument
        pdfView.autoScales = true
        
        viewController.view.addSubview(pdfView)
        
        pdfView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            pdfView.leadingAnchor.constraint(equalTo: viewController.view.leadingAnchor),
            pdfView.trailingAnchor.constraint(equalTo: viewController.view.trailingAnchor),
            pdfView.topAnchor.constraint(equalTo: viewController.view.topAnchor),
            pdfView.bottomAnchor.constraint(equalTo: viewController.view.bottomAnchor)
        ])
        
        DispatchQueue.main.async {
            if let page = pdfDocument.page(at: 0) {
                let pdfPageBounds = page.bounds(for: .mediaBox)
                self.contentHeight = pdfPageBounds.height
            }
        }
        
        return viewController
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // Nothing to update here
    }
}

struct PDFViewer: View {
    let pdfDocument: PDFDocument
    @Binding var showPDF: Bool
    @State private var contentHeight: CGFloat = 0
    
    var body: some View {
        VStack{
            //            Spacer()
            HStack {
                Spacer()
                Button(action: {
                    showPDF = false
                }) {
                    Text("Close")
                        .foregroundColor(.orange)
                        .padding()
                    //                        .background(Color.red)
                        .cornerRadius(10)
                }
                //                .padding()
            }
            //            .background(Color("orangeBackground"))
            PDFKitView(pdfDocument: pdfDocument, contentHeight: $contentHeight)
            //                .frame(height: contentHeight)
            //                .navigationTitle("PDF Viewer")
            //                .edgesIgnoringSafeArea(.all)
        }
    }
}


#Preview {
    Profile()
}

