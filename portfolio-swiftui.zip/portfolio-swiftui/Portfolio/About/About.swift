//
//  ContentView.swift
//  Portfolio
//
//  Created by Bryant Anthony Thauwrisan on 17/07/24.
//

import SwiftUI

struct About: View {
    var body: some View {
        ScrollView{
            VStack{
                Text("Hello World")
            }
        }
    }
}

#Preview {
    About()
}
